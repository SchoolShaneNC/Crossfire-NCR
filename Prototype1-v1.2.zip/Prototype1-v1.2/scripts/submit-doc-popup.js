var save = document.getElementById("submit-doc-button");



save.addEventListener("click", function(){
    alert("Document Submitted");
})
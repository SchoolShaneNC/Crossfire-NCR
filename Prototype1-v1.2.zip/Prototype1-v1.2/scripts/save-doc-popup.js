var save = document.getElementById("save-doc-button");



save.addEventListener("click", function(){
    alert("Document Saved");
})